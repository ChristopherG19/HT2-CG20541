/*---------------------------------------
       Christopher García 20541
        3er semestre - Ciclo 1
    Algoritmos y estructura de datos
---------------------------------------*/ 
//Inicio clase Interface
public interface CalculadoraGeneral {
    //Operacion calculo que opera la linea en el documento txt
    String Calculo(String operacion);

}
