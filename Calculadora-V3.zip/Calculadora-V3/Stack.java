/*---------------------------------------
       Christopher García 20541
        3er semestre - Ciclo 1
    Algoritmos y estructura de datos
---------------------------------------*/ 
//Inicio de la clase interface Stack con genéricos
public interface Stack<E>{
    
    //Método push equivalente a "add"
    void push(E Obj);
    //Método pop equivalente a remove
    E pop();
    //Método peek, consigue el primer valor del stack
    E peek();
    //Método empty, verifica si el stack está vacío o no y devuelve un boolean
    boolean empty();
    //Método size, retorna el tamaño del stack
    int size();
    
}
