public interface Stack<E>{
    
    void push(E Obj);
    E pop();
    E peek();
    boolean empty();
    int size();
    
}
