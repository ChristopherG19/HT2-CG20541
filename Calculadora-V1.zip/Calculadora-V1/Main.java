import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Vector;

public class Main {
   
   /** 
    * @param args
    */
   public static void main(String[] args) {

      Calculadora Calculadora = new Calculadora();
      Vector<String> Data = new Vector<String>();

      try {

         String x = "";
         FileReader Datos = new FileReader("datos.txt");
         BufferedReader Lector = new BufferedReader(Datos);

         while(x != null){
            x = Lector.readLine();
            if(x == null){
               break;
            }
            Data.add(x);
         }

      } catch (Exception e) {
         System.out.println("Error!! Archivo no encontrado");
      }

      for (int f = 0; f < Data.size(); f++){
         String Total = Calculadora.Calculo(Data.get(f));
         System.out.println();
         System.out.println("Resultado " + (f+1) + ": " + Total);
         System.out.println();
      }
        

   }

    

}
