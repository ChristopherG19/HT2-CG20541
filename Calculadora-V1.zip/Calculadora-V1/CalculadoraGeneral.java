public interface CalculadoraGeneral {
    
    String Calculo(String operacion);

}
