/*---------------------------------------
       Christopher García 20541
        3er semestre - Ciclo 1
    Algoritmos y estructura de datos
---------------------------------------*/ 
/**
 * Calculadora
 */
public class Calculadora implements CalculadoraGeneral{

    StackVector<Integer> stack = new StackVector<Integer>();

    
    /** 
     * @param operacion
     * @return String
     */
    @Override
    public String Calculo(String operacion) {
        
        boolean Veri = true;
        int Respuesta = 0;
        String[] operaciones;
        operaciones = operacion.split(" ");
        int Op1 = 0, Op2 = 0;
        String OpeFinal = "";

        for(int i = 0; i < operaciones.length; i ++){
            if(operaciones[i].equals("-")){
                if(stack.size() >=2){
                    Op1 = stack.pop();
                    Op2 = stack.pop();
                    Respuesta = Op2-Op1;
                    stack.push(Respuesta);
                    Veri = true; 
                }
            } else if (operaciones[i].equals("+")){
                if(stack.size() >=2){
                    Op1 = stack.pop();
                    Op2 = stack.pop();
                    Respuesta = Op2+Op1;
                    stack.push(Respuesta);
                    Veri = true; 
                }
            } else if (operaciones[i].equals("*")){
                if(stack.size() >=2){
                    Op1 = stack.pop();
                    Op2 = stack.pop();
                    Respuesta = Op2*Op1;
                    stack.push(Respuesta);
                    Veri = true; 
                }
            } else if (operaciones[i].equals("/")){
                if(stack.size() >=2){
                    try {
                        if(Op1 == 0){
                            System.out.println("La division dentro de 0 no existe");
                        } else {
                            Op1 = stack.pop();
                            Op2 = stack.pop();
                            Respuesta = Op2 / Op1;
                            stack.push(Respuesta);
                            Veri = true;
                        }
                    } catch (Exception e){
                        System.out.println("Lo sentimos esta division no se puede");
                    }
                }
            } else if (operaciones[i].equals("(")){
                System.out.println("Lo sentimos pero este caracter es invalido");
                Veri = false;
            } else if (operaciones[i].equals(")")){
                System.out.println("Lo sentimos pero este caracter es invalido");
                Veri = false;
                      
            } else {
                Veri = false;
                int operador = Integer.parseInt(operaciones[i]);
                stack.push(operador);
            }
        }

        if(Veri == true){
            OpeFinal = Integer.toString(stack.pop());
        } else if (Veri == false){
            OpeFinal = "Lo sentimos, no es posible operar esta expresion";
        }

        return OpeFinal;
    }

}