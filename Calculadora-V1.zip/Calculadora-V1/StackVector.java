import java.util.Vector;

public class StackVector<E> implements Stack<E> {

    protected Vector<E> data;

    public StackVector(){
        data = new Vector<E>();
    }

    
    /** 
     * @param num
     */
    @Override
    public void push(E num) {
        data.add(num);
    }
    
    
    /** 
     * @return E
     */
    @Override
    public E pop() {
        return data.remove(data.size()-1);
    }

    
    /** 
     * @return E
     */
    @Override
    public E peek() {
        return data.get(data.size()-1);
    }

    
    /** 
     * @return boolean
     */
    @Override
    public boolean empty() {
       return size() == 0;
    }

    
    /** 
     * @return int
     */
    @Override
    public int size() {
        return data.size();
    }


    
}
